const express = require('express');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ──
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
    },
  },
}));
app.use(cors());
app.use(express.json());

// ── Serve static frontend ──
app.use(express.static(path.join(__dirname, '../public')));

// ── API Routes ──

// POST /api/booking  — save a booking (in-memory for demo; swap with DB later)
const bookings = [];

app.post('/api/booking', (req, res) => {
  const { name, phone, service, address } = req.body;

  if (!name || !phone || !service) {
    return res.status(400).json({ error: 'name, phone and service are required' });
  }

  const booking = {
    id: Date.now().toString(),
    name,
    phone,
    service,
    address: address || '',
    status: 'confirmed',
    professional: { name: 'Rajesh Kumar', rating: 4.9, eta: 12 },
    amount: 382,
    createdAt: new Date().toISOString(),
  };

  bookings.push(booking);
  console.log(`[Booking] ${booking.id} — ${name} — ${service}`);

  res.status(201).json({ success: true, booking });
});

// GET /api/bookings  — list all bookings (admin/demo endpoint)
app.get('/api/bookings', (req, res) => {
  res.json({ count: bookings.length, bookings });
});

// GET /api/health  — health check for Render
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

// Fallback — serve index.html for any unknown route (SPA support)
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, () => {
  console.log(`✅  FixIt Pro server running on http://localhost:${PORT}`);
});
