# 🔧 FixIt Pro — On-Demand Home Services

India's most trusted on-demand home services platform.

---

## 📁 Project Structure

```
fixit-pro/
├── public/
│   └── index.html        ← Full frontend (HTML + CSS + JS)
├── server/
│   └── index.js          ← Express.js backend
├── package.json
├── .gitignore
└── README.md
```

---

## 🚀 Deploy in 3 Steps

### Step 1 — Push to GitHub

```bash
# In your terminal:
git init
git add .
git commit -m "Initial commit — FixIt Pro"

# Create a new repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/fixit-pro.git
git branch -M main
git push -u origin main
```

### Step 2 — Deploy on Render

1. Go to **https://render.com** and sign in (free account works)
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub account and select the `fixit-pro` repo
4. Fill in these settings:

| Setting | Value |
|---|---|
| **Name** | fixit-pro |
| **Environment** | Node |
| **Build Command** | `npm install` |
| **Start Command** | `npm start` |
| **Instance Type** | Free |

5. Click **"Create Web Service"** — Render will build and deploy automatically.
6. Your live URL will be: `https://fixit-pro.onrender.com` (or similar)

### Step 3 — Done! ✅

Your site is live. Every `git push` to `main` will auto-redeploy.

---

## 🛠️ Run Locally

```bash
npm install
npm start
# Open http://localhost:3000
```

For live-reload during development:
```bash
npm run dev
```

---

## 🔌 API Endpoints

| Method | Route | Description |
|---|---|---|
| `GET` | `/` | Serves the frontend |
| `GET` | `/api/health` | Health check (used by Render) |
| `POST` | `/api/booking` | Create a new booking |
| `GET` | `/api/bookings` | List all bookings (demo) |

### POST /api/booking — Request body

```json
{
  "name": "Amit Sharma",
  "phone": "9876543210",
  "service": "Plumbing — Pipe Repair",
  "address": "Shanti Nagar, Raipur"
}
```

---

## 🗄️ Adding a Real Database (Optional Upgrade)

Replace the in-memory `bookings` array in `server/index.js` with MongoDB:

```bash
npm install mongoose
```

Then add to `server/index.js`:
```js
const mongoose = require('mongoose');
mongoose.connect(process.env.MONGODB_URI);
```

Add `MONGODB_URI` as an **Environment Variable** in Render dashboard.

---

Made with ♥ in India · FixIt Pro Technologies Pvt. Ltd.
